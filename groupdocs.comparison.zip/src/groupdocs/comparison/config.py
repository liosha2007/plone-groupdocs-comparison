"""Common configuration constants
"""

PROJECTNAME = 'groupdocs.comparison'

ADD_PERMISSIONS = {
    # -*- extra stuff goes here -*-
}
